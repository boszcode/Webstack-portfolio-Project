<?php

return [

    'name'              => 'Pureadmindash',
    'description'       => 'This is my awesome module',

];